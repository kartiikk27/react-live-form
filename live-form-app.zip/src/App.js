import React from 'react';
import LiveForm from './LiveForm';

function App() {
  return (
    <div>
      <LiveForm />
    </div>
  );
}

export default App;
